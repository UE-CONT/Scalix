package scalix

object Config :
  val api_key = "0c24cdcbfd900df16635b9082a52c603"
// Put your own api key